<?php
    namespace descartes\exceptions;

    class DescartesExceptionRouterInvocationError extends \Exception {};
    
