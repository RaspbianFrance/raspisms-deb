<div class="popup-alert alert alert-<?php $this->s($type); ?> alert-dismissible show" role="alert">
    <?php $this->s($text); ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
