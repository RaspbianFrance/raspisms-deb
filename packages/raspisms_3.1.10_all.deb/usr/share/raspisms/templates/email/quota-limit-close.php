Vous avez atteint <?php echo $percent * 100; ?>% de votre quota de SMS.

--------------------------------------------------------------------------------------------
Pour plus d'informations sur le système RaspiSMS, rendez-vous sur le site https://raspisms.fr
