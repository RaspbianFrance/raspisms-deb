Vous avez reçu un nouveau SMS : 
Date : <?= $at ?>

Origine : <?= $origin ?>

Destination : <?= $destination ?>

Message : <?= $text ?>
