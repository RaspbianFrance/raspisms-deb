<?php
    namespace descartes\exceptions;

    class DescartesException404 extends \Exception {};
    
