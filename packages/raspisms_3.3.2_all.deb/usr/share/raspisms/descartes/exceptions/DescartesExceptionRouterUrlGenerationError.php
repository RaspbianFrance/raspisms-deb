<?php
    namespace descartes\exceptions;

    class DescartesExceptionRouterUrlGenerationError extends \Exception {};
    
