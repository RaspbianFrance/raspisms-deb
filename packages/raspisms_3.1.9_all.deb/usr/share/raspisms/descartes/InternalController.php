<?php
    namespace descartes;

    /**
     * Cette classe sert de mère à tous les controlleurs internes
	 */
	class InternalController extends Controller
	{
	} 
