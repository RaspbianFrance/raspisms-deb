Vous avez reçu un nouveau SMS : 
Date : <?= $sms['at'] ?>
Origine : <?= $sms['origin'] ?>
Destination : <?= $sms['destination'] ?>
Message : <?= $sms['text'] ?>
