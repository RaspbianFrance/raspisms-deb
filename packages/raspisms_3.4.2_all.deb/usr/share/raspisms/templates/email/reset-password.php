Vous avez demandé la ré-initialisation de votre mot de passe pour le site <?php echo HTTP_PWD; ?>.
Pour ré-initialisez votre mot de passe, rendez-vous à l'adresse suivante : <?php echo $reset_link; ?>.

--------------------------------------------------------------------------------------------
Pour plus d'informations sur le système RaspiSMS, rendez-vous sur le site https://raspisms.fr
