<?php
    namespace descartes\exceptions;

    class DescartesExceptionSqlError extends \Exception {};
    
