Vous avez reçu un nouveau <?= $mms ? 'MMS' : 'SMS'; ?> : 
Date : <?= $at ?>

Origine : <?= $origin ?>

Destination : <?= $destination ?>

Message : <?= $text ?>
