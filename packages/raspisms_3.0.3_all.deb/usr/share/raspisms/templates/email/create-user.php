Votre compte a été créé sur le site <?php echo HTTP_PWD; ?> avec les identifiants suivants : 
Adresse e-mail : <?php echo $email; ?>

Mot de passe : <?php echo $password; ?>

--------------------------------------------------------------------------------------------
Pour plus d'informations sur le système RaspiSMS, rendez-vous sur le site https://raspisms.raspberry-pi.fr
