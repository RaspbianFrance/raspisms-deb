<?php
    namespace descartes\exceptions;

    class DescartesExceptionConsoleInvocationError extends \Exception {};
    
