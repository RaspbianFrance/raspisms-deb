Vous avez épuisé votre quota de SMS, vous ne pourrez plus envoyer de SMS tant que votre quota de SMS n'aura pas été augmenté ou remis à zéro.
<?php if ($expiration_date ?? false) { ?>Votre quota sera remis à zéro le <?php $this->s($expiration_date); ?>.<?php } ?>

--------------------------------------------------------------------------------------------
Pour plus d'informations sur le système RaspiSMS, rendez-vous sur le site https://raspisms.fr
