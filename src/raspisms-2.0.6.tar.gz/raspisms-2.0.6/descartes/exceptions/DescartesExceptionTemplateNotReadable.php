<?php
    namespace descartes\exceptions;

    class DescartesExceptionTemplateNotReadable extends \Exception {};
    
