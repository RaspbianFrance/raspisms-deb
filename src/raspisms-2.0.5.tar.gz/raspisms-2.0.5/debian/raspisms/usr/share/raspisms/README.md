# RaspiSMS
RaspiSMS est un logiciel dedié à l'envoie et à la gestion de SMS depuis un ordinateur.
Il a été originellement conçu pour la Raspberry Pi.

RaspiSMS est une création de https://raspberry-pi.fr et est distribué sous license GNU/GPL v3

Une documentation plus complète sur RaspiSMS est disponible à l'adresse https://raspisms.raspberry-pi.fr/
